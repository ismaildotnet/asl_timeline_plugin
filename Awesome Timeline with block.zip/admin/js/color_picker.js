jQuery(document).ready(function($){
    $('.timeline-color-field').wpColorPicker();
});
