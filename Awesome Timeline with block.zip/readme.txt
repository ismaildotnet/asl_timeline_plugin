=== Awesome Timeline ===
Contributors: [alchemysoftwarelimited](https://profiles.wordpress.org/alchemysoftwarelimited/)
Donate link: https://alchemy-bd.com/
Tags: timeline, awesome timeline, event line, event tree, tree post, schedule event
Requires at least: 4.0
Tested up to: 6.4.1
Requires PHP: 7.2
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

This program is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License as published by the
Free Software Foundation; either version 2 of the License, or (at your
option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.

-----------------------------------------------------------------------
[Awesome Timeline]

Copyright (C) [2023] [Alchemy Software Limited]

Awesome Timeline is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.

Awesome Timeline is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with Awesome Timeline. If not, see <http://www.gnu.org/licenses/>.
